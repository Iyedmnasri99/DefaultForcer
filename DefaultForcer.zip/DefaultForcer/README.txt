Default Forcer - LSPosed/Vector module
Build: open this folder in Android Studio (Sync, then Build > Build APK), or run `gradle assembleDebug`.
Install APK -> Vector manager -> enable module, scope "System Framework" -> reboot.
Open the app, tap a category, choose the app to force.
Logs: Vector manager -> Logs, search "DefaultForcer".
