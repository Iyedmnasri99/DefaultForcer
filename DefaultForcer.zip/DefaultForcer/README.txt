Default Forcer 1.1 - LSPosed/Vector module (Material 3 + Monet UI)
Build: push to GitHub and run the "Build APK" workflow (or open in Android Studio).
Install APK -> Vector -> enable module, scope "System Framework" -> reboot.
