package dev.defaultforcer;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Binder;
import android.webkit.MimeTypeMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Hook implements IXposedHookLoadPackage {
    private XSharedPreferences prefs;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if ("dev.defaultforcer".equals(lpparam.packageName)) {
            try {
                XposedHelpers.findAndHookMethod("dev.defaultforcer.MainActivity", lpparam.classLoader,
                        "isModuleActive", XC_MethodReplacement.returnConstant(true));
            } catch (Throwable t) {
                XposedBridge.log("DefaultForcer: self hook failed " + t);
            }
            return;
        }
        if (!"android".equals(lpparam.packageName)) return;
        prefs = new XSharedPreferences("dev.defaultforcer", "rules");
        try {
            Class<?> atms = XposedHelpers.findClass(
                    "com.android.server.wm.ActivityTaskManagerService", lpparam.classLoader);
            XposedBridge.hookAllMethods(atms, "startActivityAsUser", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try { redirect(p); }
                    catch (Throwable t) { XposedBridge.log("DefaultForcer: " + t); }
                }
            });
            XposedBridge.log("DefaultForcer: hooked startActivityAsUser");
        } catch (Throwable t) {
            XposedBridge.log("DefaultForcer: hook failed " + t);
        }
    }

    private void redirect(XC_MethodHook.MethodHookParam p) {
        Object[] a = p.args;
        int i = -1;
        for (int k = 0; k < a.length; k++) if (a[k] instanceof Intent) { i = k; break; }
        if (i < 0) return;
        Intent intent = (Intent) a[i];

        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return;
        if (intent.getComponent() != null || intent.getPackage() != null
                || intent.getSelector() != null) return;
        Uri data = intent.getData();
        if (data == null) return;
        String scheme = data.getScheme();
        if (!"content".equals(scheme) && !"file".equals(scheme)) return;

        String type = (i + 1 < a.length && a[i + 1] instanceof String) ? (String) a[i + 1] : null;
        if (type == null) type = intent.getType();
        if (type == null) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(data.toString());
            if (ext != null && !ext.isEmpty())
                type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        }
        String cat = category(type);
        if (cat == null) return;

        if (prefs.hasFileChanged()) prefs.reload();
        if (!prefs.getBoolean("enabled", true)) return;
        String target = prefs.getString("target_" + cat, null);
        if (target == null || target.isEmpty()) return;

        Context ctx = (Context) XposedHelpers.getObjectField(p.thisObject, "mContext");
        Intent test = new Intent(intent);
        test.setDataAndType(data, type);
        test.setPackage(target);
        long id = Binder.clearCallingIdentity();
        try {
            if (ctx.getPackageManager()
                    .queryIntentActivities(test, PackageManager.MATCH_DEFAULT_ONLY).isEmpty()) return;
        } finally {
            Binder.restoreCallingIdentity(id);
        }
        intent.setPackage(target);
        XposedBridge.log("DefaultForcer: " + type + " -> " + target);
    }

    static String category(String type) {
        if (type == null) return null;
        String t = type.toLowerCase();
        if (t.startsWith("video/")) return "video";
        if (t.startsWith("audio/")) return "audio";
        if (t.startsWith("image/")) return "image";
        if (t.equals("application/pdf")) return "pdf";
        if (t.startsWith("text/")) return "text";
        if (t.equals("application/msword") || t.startsWith("application/vnd.ms-")
                || t.startsWith("application/vnd.openxmlformats-officedocument.")
                || t.startsWith("application/vnd.oasis.opendocument.")) return "docs";
        if (t.equals("application/zip") || t.equals("application/x-7z-compressed")
                || t.equals("application/vnd.rar") || t.equals("application/x-rar-compressed")
                || t.equals("application/x-tar") || t.equals("application/gzip")
                || t.equals("application/x-gzip")) return "archive";
        return null;
    }
}
