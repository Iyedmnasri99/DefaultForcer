package dev.defaultforcer;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Binder;
import android.webkit.MimeTypeMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Hook implements IXposedHookLoadPackage {
    private XSharedPreferences prefs;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"android".equals(lpparam.packageName)) return;
        prefs = new XSharedPreferences("dev.defaultforcer", "rules");
        try {
            Class<?> atms = XposedHelpers.findClass(
                    "com.android.server.wm.ActivityTaskManagerService", lpparam.classLoader);
            XposedBridge.hookAllMethods(atms, "startActivityAsUser", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try { redirect(p); }
                    catch (Throwable t) { XposedBridge.log("DefaultForcer: " + t); }
                }
            });
            XposedBridge.log("DefaultForcer: hooked startActivityAsUser");
        } catch (Throwable t) {
            XposedBridge.log("DefaultForcer: hook failed " + t);
        }
    }

    private void redirect(XC_MethodHook.MethodHookParam p) {
        Object[] a = p.args;
        int i = -1;
        for (int k = 0; k < a.length; k++) if (a[k] instanceof Intent) { i = k; break; }
        if (i < 0) return;
        Intent intent = (Intent) a[i];

        if (!Intent.ACTION_VIEW.equals(intent.getAction())) return;
        if (intent.getComponent() != null || intent.getPackage() != null
                || intent.getSelector() != null) return;
        Uri data = intent.getData();
        if (data == null) return;
        String scheme = data.getScheme();
        if (!"content".equals(scheme) && !"file".equals(scheme)) return;

        String type = (i + 1 < a.length && a[i + 1] instanceof String) ? (String) a[i + 1] : null;
        if (type == null) type = intent.getType();
        if (type == null) {
            String ext = MimeTypeMap.getFileExtensionFromUrl(data.toString());
            if (ext != null && !ext.isEmpty())
                type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase());
        }
        String cat = category(type);
        if (cat == null) return;

        if (prefs.hasFileChanged()) prefs.reload();
        String target = prefs.getString("target_" + cat, null);
        if (target == null || target.isEmpty()) return;

        Context ctx = (Context) XposedHelpers.getObjectField(p.thisObject, "mContext");
        Intent test = new Intent(intent);
        test.setDataAndType(data, type);
        test.setPackage(target);
        long id = Binder.clearCallingIdentity();
        try {
            if (ctx.getPackageManager()
                    .queryIntentActivities(test, PackageManager.MATCH_DEFAULT_ONLY).isEmpty()) return;
        } finally {
            Binder.restoreCallingIdentity(id);
        }
        intent.setPackage(target);
        XposedBridge.log("DefaultForcer: " + type + " -> " + target);
    }

    static String category(String type) {
        if (type == null) return null;
        type = type.toLowerCase();
        if (type.startsWith("video/")) return "video";
        if (type.startsWith("audio/")) return "audio";
        if (type.startsWith("image/")) return "image";
        if (type.equals("application/pdf")) return "pdf";
        if (type.startsWith("text/")) return "text";
        return null;
    }
}
