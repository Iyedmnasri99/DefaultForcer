package dev.defaultforcer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.color.DynamicColors;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.shape.ShapeAppearanceModel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    static final class Cat {
        final String key, label, hint, mime, uri;
        final int icon;
        Cat(String key, String label, String hint, String mime, String uri, int icon) {
            this.key = key; this.label = label; this.hint = hint;
            this.mime = mime; this.uri = uri; this.icon = icon;
        }
    }

    static final Cat[] CATS = {
        new Cat("video", "Video", "MP4, MKV, WebM and more", "video/mp4",
                "content://media/external/video/media/1", R.drawable.ic_video),
        new Cat("audio", "Music and audio", "MP3, FLAC, M4A and more", "audio/mpeg",
                "content://media/external/audio/media/1", R.drawable.ic_audio),
        new Cat("image", "Photos", "JPG, PNG, WebP and more", "image/jpeg",
                "content://media/external/images/media/1", R.drawable.ic_image),
        new Cat("pdf", "PDF", "PDF documents", "application/pdf",
                "content://x/doc.pdf", R.drawable.ic_pdf),
        new Cat("text", "Text", "TXT, logs and code", "text/plain",
                "content://x/note.txt", R.drawable.ic_text),
        new Cat("docs", "Office documents", "Word, Excel, PowerPoint",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "content://x/file.docx", R.drawable.ic_docs),
        new Cat("archive", "Archives", "ZIP, 7z, RAR, TAR", "application/zip",
                "content://x/file.zip", R.drawable.ic_archive),
    };

    private SharedPreferences sp;
    private boolean worldReadable;
    private LinearLayout cardList;
    private MaterialCardView statusCard;
    private ImageView statusIcon;
    private TextView statusTitle, statusBody;

    /** Hooked by the module itself: returns true when Vector/LSPosed loaded it. */
    static boolean isModuleActive() { return false; }

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DynamicColors.applyToActivityIfAvailable(this);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        try {
            sp = getSharedPreferences("rules", MODE_WORLD_READABLE);
            worldReadable = true;
        } catch (SecurityException e) {
            sp = getSharedPreferences("rules", MODE_PRIVATE);
            worldReadable = false;
        }
        setContentView(R.layout.activity_main);

        ScrollView scroll = findViewById(R.id.scroll);
        ViewCompat.setOnApplyWindowInsetsListener(scroll, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        cardList = findViewById(R.id.cardList);
        statusCard = findViewById(R.id.statusCard);
        statusIcon = findViewById(R.id.statusIcon);
        statusTitle = findViewById(R.id.statusTitle);
        statusBody = findViewById(R.id.statusBody);

        MaterialSwitch master = findViewById(R.id.masterSwitch);
        boolean on = sp.getBoolean("enabled", true);
        master.setChecked(on);
        cardList.setAlpha(on ? 1f : 0.5f);
        master.setOnCheckedChangeListener((button, checked) -> {
            sp.edit().putBoolean("enabled", checked).apply();
            cardList.setAlpha(checked ? 1f : 0.5f);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int color(int attr) {
        return MaterialColors.getColor(this, attr, 0);
    }

    private ShapeAppearanceModel shape(boolean first, boolean last) {
        float big = dp(28), small = dp(6);
        return new ShapeAppearanceModel().toBuilder()
                .setTopLeftCornerSize(first ? big : small)
                .setTopRightCornerSize(first ? big : small)
                .setBottomLeftCornerSize(last ? big : small)
                .setBottomRightCornerSize(last ? big : small)
                .build();
    }

    private void refresh() {
        PackageManager pm = getPackageManager();
        LayoutInflater inf = getLayoutInflater();
        cardList.removeAllViews();
        int forced = 0;

        for (int i = 0; i < CATS.length; i++) {
            final Cat c = CATS[i];
            MaterialCardView card = (MaterialCardView) inf.inflate(R.layout.item_category, cardList, false);
            ((ImageView) card.findViewById(R.id.catIcon)).setImageResource(c.icon);
            ((TextView) card.findViewById(R.id.catTitle)).setText(c.label);
            TextView sub = card.findViewById(R.id.catSub);
            ImageView appIcon = card.findViewById(R.id.catAppIcon);

            String pkg = sp.getString("target_" + c.key, null);
            if (pkg == null) {
                sub.setText(c.hint);
            } else {
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                    sub.setText("Opens in " + pm.getApplicationLabel(ai));
                    sub.setTextColor(color(androidx.appcompat.R.attr.colorPrimary));
                    appIcon.setImageDrawable(pm.getApplicationIcon(pkg));
                    appIcon.setVisibility(View.VISIBLE);
                    forced++;
                } catch (PackageManager.NameNotFoundException e) {
                    sub.setText("App not installed, using the chooser");
                }
            }
            card.setShapeAppearanceModel(shape(i == 0, i == CATS.length - 1));
            card.setOnClickListener(v -> pick(c));
            cardList.addView(card);
        }

        boolean ok = worldReadable && isModuleActive();
        statusCard.setCardBackgroundColor(color(ok
                ? com.google.android.material.R.attr.colorPrimaryContainer
                : com.google.android.material.R.attr.colorErrorContainer));
        int on = color(ok
                ? com.google.android.material.R.attr.colorOnPrimaryContainer
                : com.google.android.material.R.attr.colorOnErrorContainer);
        statusIcon.setImageResource(ok ? R.drawable.ic_check_circle : R.drawable.ic_warning);
        statusIcon.setImageTintList(ColorStateList.valueOf(on));
        statusTitle.setTextColor(on);
        statusBody.setTextColor(on);
        if (ok) {
            statusTitle.setText("Module loaded");
            statusBody.setText(forced + " of " + CATS.length
                    + " file types forced. System Framework must stay ticked in the scope.");
        } else {
            statusTitle.setText("Module not active");
            statusBody.setText("Enable it in Vector, tick System Framework in the scope, then reboot.");
        }
    }

    private void pick(Cat c) {
        PackageManager pm = getPackageManager();
        Intent probe = new Intent(Intent.ACTION_VIEW);
        probe.setDataAndType(Uri.parse(c.uri), c.mime);
        Map<String, ResolveInfo> apps = new LinkedHashMap<>();
        for (ResolveInfo r : pm.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY)) {
            String p = r.activityInfo.packageName;
            if (!p.equals(getPackageName()) && !apps.containsKey(p)) apps.put(p, r);
        }
        List<String> pkgs = new ArrayList<>(apps.keySet());
        final PackageManager fpm = pm;
        Collections.sort(pkgs, (x, y) -> apps.get(x).loadLabel(fpm).toString()
                .compareToIgnoreCase(apps.get(y).loadLabel(fpm).toString()));

        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View sheet = getLayoutInflater().inflate(R.layout.sheet_pick, null);
        ((TextView) sheet.findViewById(R.id.sheetTitle)).setText("Open " + c.label.toLowerCase() + " with");
        LinearLayout list = sheet.findViewById(R.id.sheetList);
        String current = sp.getString("target_" + c.key, null);

        View none = row(list, "Don't force", "Use the normal system chooser", null, current == null);
        none.setOnClickListener(v -> save(c, null, dialog));
        list.addView(none);

        if (pkgs.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("No installed app can open this type of file.");
            empty.setPadding(dp(24), dp(16), dp(24), dp(16));
            list.addView(empty);
        }
        for (String p : pkgs) {
            ResolveInfo r = apps.get(p);
            View row = row(list, r.loadLabel(pm).toString(), p, r.loadIcon(pm), p.equals(current));
            row.setOnClickListener(v -> save(c, p, dialog));
            list.addView(row);
        }

        dialog.setContentView(sheet);
        dialog.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
        dialog.show();
    }

    private View row(LinearLayout parent, String name, String sub,
                     android.graphics.drawable.Drawable icon, boolean selected) {
        View v = getLayoutInflater().inflate(R.layout.item_app, parent, false);
        ((TextView) v.findViewById(R.id.appName)).setText(name);
        ((TextView) v.findViewById(R.id.appPkg)).setText(sub);
        ImageView iv = v.findViewById(R.id.appIcon);
        if (icon != null) {
            iv.setImageDrawable(icon);
        } else {
            iv.setImageResource(R.drawable.ic_close);
            iv.setPadding(dp(8), dp(8), dp(8), dp(8));
            iv.setImageTintList(ColorStateList.valueOf(
                    color(com.google.android.material.R.attr.colorOnSurfaceVariant)));
        }
        v.findViewById(R.id.appCheck).setVisibility(selected ? View.VISIBLE : View.GONE);
        return v;
    }

    private void save(Cat c, String pkg, BottomSheetDialog dialog) {
        SharedPreferences.Editor e = sp.edit();
        if (pkg == null) e.remove("target_" + c.key);
        else e.putString("target_" + c.key, pkg);
        e.apply();
        dialog.dismiss();
        refresh();
    }
}
