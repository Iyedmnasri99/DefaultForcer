package dev.defaultforcer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    // key, label, sample mime, sample uri
    static final String[][] CATS = {
        {"video", "Video", "video/mp4", "content://media/external/video/media/1"},
        {"audio", "Music / audio", "audio/mpeg", "content://media/external/audio/media/1"},
        {"image", "Photos", "image/jpeg", "content://media/external/images/media/1"},
        {"pdf", "PDF", "application/pdf", "content://x/doc.pdf"},
        {"text", "Text", "text/plain", "content://x/note.txt"},
    };

    private SharedPreferences sp;
    private ListView list;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = getSharedPreferences("rules", MODE_WORLD_READABLE);
        } catch (SecurityException e) {
            sp = getSharedPreferences("rules", MODE_PRIVATE);
            Toast.makeText(this, "Module not active in Vector/LSPosed: enable it, scope System Framework, reboot",
                    Toast.LENGTH_LONG).show();
        }
        list = new ListView(this);
        setContentView(list);
        list.setOnItemClickListener((p, v, pos, id) -> pick(CATS[pos]));
        refresh();
    }

    private void refresh() {
        List<String> rows = new ArrayList<>();
        for (String[] c : CATS) {
            String pkg = sp.getString("target_" + c[0], null);
            rows.add(c[1] + "\n" + (pkg == null ? "Not forced (system chooser)" : "-> " + label(pkg) + " (" + pkg + ")"));
        }
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows));
    }

    private String label(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return pkg; }
    }

    private void pick(String[] c) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(c[3]), c[2]);
        PackageManager pm = getPackageManager();
        Map<String, String> apps = new LinkedHashMap<>();
        for (ResolveInfo r : pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY))
            apps.put(r.activityInfo.packageName, r.loadLabel(pm).toString());
        List<String> pkgs = new ArrayList<>(apps.keySet());
        List<String> names = new ArrayList<>();
        names.add("Don't force");
        for (String p : pkgs) names.add(apps.get(p) + "\n" + p);
        new AlertDialog.Builder(this).setTitle(c[1])
            .setItems(names.toArray(new String[0]), (d, which) -> {
                SharedPreferences.Editor e = sp.edit();
                if (which == 0) e.remove("target_" + c[0]);
                else e.putString("target_" + c[0], pkgs.get(which - 1));
                e.apply();
                refresh();
            }).show();
    }
}
