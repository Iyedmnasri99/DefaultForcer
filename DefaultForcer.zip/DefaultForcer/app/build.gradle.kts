plugins { id("com.android.application") }

android {
    namespace = "dev.defaultforcer"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.defaultforcer"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies { compileOnly("de.robv.android.xposed:api:82") }
